#!/usr/bin/bash

if [ $# -ne 1 ]; then
	echo "please provide the zip file";
	exit -1;
fi

wait_print(){
	while [ $counter -lt $1 ]; do
		sleep 1;
		echo -n "# ";
		counter=$((counter+1))
	done
}

clear;
echo "extracting zip file";
tar xfj $1;
echo ".....DONE.....";
echo
counter=0;

echo "launching configuration in 5 seconds"
echo "this operation might take time, be patient...";

wait_print 5;

clear;
$(find . -maxdepth 1 -type d | tail -1)/ns-3.38/ns3 configure --enable-examples --enable-tests;

echo ".....DONE.....";
echo;

echo "the next step will install some required packages";

wait_print 5;



$(find . -maxdepth 1 -type d | tail -1)/ns-3.38/ns3 build;

#$(find . -maxdepth 1 -type d | tail -1)/bake/bake.py install;




